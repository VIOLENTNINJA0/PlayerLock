package com.example.playerlock.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface PlayerBadgeDao {

    @Query("SELECT * FROM player_badges WHERE profileId = :profileId ORDER BY id ASC")
    fun getAllBadgesFlow(profileId: Int): Flow<List<PlayerBadge>>

    @Query("SELECT * FROM player_badges WHERE profileId = :profileId ORDER BY id ASC")
    suspend fun getAllBadges(profileId: Int): List<PlayerBadge>

    @Query("SELECT * FROM player_badges WHERE id = :id")
    suspend fun getBadgeById(id: Int): PlayerBadge?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBadges(badges: List<PlayerBadge>)

    @Update
    suspend fun updateBadge(badge: PlayerBadge)

    @Query("SELECT COUNT(*) FROM player_badges WHERE profileId = :profileId")
    suspend fun countBadges(profileId: Int): Int
}
