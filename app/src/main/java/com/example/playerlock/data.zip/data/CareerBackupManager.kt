package com.example.playerlock.data

import com.example.playerlock.progression.ProgressionRepository
import org.json.JSONArray
import org.json.JSONObject

class CareerBackupManager(
    private val repository: ProgressionRepository,
    private val settingsDataStore: SettingsDataStore
) {

    /**
     * Serializes the active player profile along with all attributes, badges, game logs,
     * and upgrade history into a clean formatted JSON string.
     */
    suspend fun exportCareerToJson(profileId: Int): String? {
        val profile = repository.getProfile(profileId) ?: return null

        val attributes = repository.getAllAttributesList(profileId)
        val badges = repository.getAllBadges(profileId)
        val gameLogs = repository.getAllGameLogs(profileId)
        val upgradeHistory = repository.getAllUpgradeHistory(profileId)
        val awards = repository.getAllAwards(profileId)

        val rootJson = JSONObject()
        rootJson.put("version", 1)

        val profileJson = JSONObject().apply {
            put("playerName", profile.playerName)
            put("position", profile.position)
            put("overallRating", profile.overallRating)
            put("availableAp", profile.availableAp)
            put("availableBp", profile.availableBp)
            put("xpRemainderForAp", profile.xpRemainderForAp)
            put("xpRemainderForBp", profile.xpRemainderForBp)
            put("avatarPath", profile.avatarPath)
            put("heightInches", profile.heightInches)
            put("weightLbs", profile.weightLbs)
            put("jerseyNumber", profile.jerseyNumber)
            put("teamName", profile.teamName)
            put("createdAt", profile.createdAt)
        }
        rootJson.put("profile", profileJson)

        val attrArray = JSONArray()
        attributes.forEach { attr ->
            val attrJson = JSONObject().apply {
                put("category", attr.category)
                put("attributeName", attr.attributeName)
                put("currentValue", attr.currentValue)
                put("maxValue", attr.maxValue)
            }
            attrArray.put(attrJson)
        }
        rootJson.put("attributes", attrArray)

        val badgeArray = JSONArray()
        badges.forEach { badge ->
            val badgeJson = JSONObject().apply {
                put("badgeName", badge.badgeName)
                put("tier", badge.tier)
                put("equipped", badge.equipped)
                put("category", badge.category)
            }
            badgeArray.put(badgeJson)
        }
        rootJson.put("badges", badgeArray)

        val logArray = JSONArray()
        gameLogs.forEach { log ->
            val logJson = JSONObject().apply {
                put("datePlayed", log.datePlayed)
                put("points", log.points)
                put("rebounds", log.rebounds)
                put("assists", log.assists)
                put("steals", log.steals)
                put("blocks", log.blocks)
                put("turnovers", log.turnovers)
                put("fieldGoalsAttempted", log.fieldGoalsAttempted)
                put("fieldGoalsMade", log.fieldGoalsMade)
                put("freeThrowsAttempted", log.freeThrowsAttempted)
                put("freeThrowsMade", log.freeThrowsMade)
                put("isWin", log.isWin)
                put("isPlayoff", log.isPlayoff)
                put("teammateGrade", log.teammateGrade)
                put("quarterMinutes", log.quarterMinutes)
                put("playerOfTheGame", log.playerOfTheGame)
                put("playerOfTheWeek", log.playerOfTheWeek)
                put("allStar", log.allStar)
                put("majorAward", log.majorAward)
            }
            logArray.put(logJson)
        }
        rootJson.put("gameLogs", logArray)

        val attrMap = attributes.associateBy { it.id }
        val badgeMap = badges.associateBy { it.id }

        val historyArray = JSONArray()
        upgradeHistory.forEach { history ->
            val entityName = when (history.entityType) {
                "ATTRIBUTE" -> attrMap[history.entityId]?.attributeName ?: ""
                "BADGE" -> badgeMap[history.entityId]?.badgeName ?: ""
                else -> ""
            }
            val historyJson = JSONObject().apply {
                put("entityType", history.entityType)
                put("entityId", history.entityId)
                put("entityName", entityName)
                put("oldValue", history.oldValue)
                put("newValue", history.newValue)
                put("costSpent", history.costSpent)
                put("currencyType", history.currencyType)
                put("isAppliedIn2k", history.isAppliedIn2k)
                put("timestamp", history.timestamp)
            }
            historyArray.put(historyJson)
        }
        rootJson.put("upgradeHistory", historyArray)

        val awardArray = JSONArray()
        awards.forEach { award ->
            val awardJson = JSONObject().apply {
                put("awardName", award.awardName)
                put("category", award.category)
                put("seasonNumber", award.seasonNumber)
                put("xpGranted", award.xpGranted)
                put("timestamp", award.timestamp)
            }
            awardArray.put(awardJson)
        }
        rootJson.put("playerAwards", awardArray)

        return rootJson.toString(2)
    }

    /**
     * Parses the JSON string, creates a brand new profile (preventing overwrites),
     * inserts all related records under the new profile ID, and sets activeProfileId.
     */
    suspend fun importCareerFromJson(jsonString: String): Int {
        val newProfileId = repository.importCareerFromJson(jsonString)
        settingsDataStore.setActiveProfileId(newProfileId)
        return newProfileId
    }
}
