package com.example.playerlock.data

import androidx.compose.ui.graphics.Color

data class NbaTeamScheme(
    val name: String,
    val abbreviation: String,
    val primaryColor: Color,
    val secondaryColor: Color,
    val numberColor: Color
)

object NbaTeamCatalog {

    val TEAMS: List<NbaTeamScheme> = listOf(
        NbaTeamScheme("Draft Prospect", "PRO", Color(0xFF1E1E1E), Color(0xFFFFB300), Color(0xFFFFFFFF)),
        NbaTeamScheme("Los Angeles Lakers", "LAL", Color(0xFF552583), Color(0xFFFDB927), Color(0xFFFFFFFF)),
        NbaTeamScheme("Boston Celtics", "BOS", Color(0xFF007A33), Color(0xFFFFFFFF), Color(0xFFFFFFFF)),
        NbaTeamScheme("Chicago Bulls", "CHI", Color(0xFFCE1141), Color(0xFF000000), Color(0xFFFFFFFF)),
        NbaTeamScheme("Golden State Warriors", "GSW", Color(0xFF1D428A), Color(0xFFFFC72C), Color(0xFFFFFFFF)),
        NbaTeamScheme("Miami Heat", "MIA", Color(0xFF98002E), Color(0xFFF9A01B), Color(0xFFFFFFFF)),
        NbaTeamScheme("New York Knicks", "NYK", Color(0xFF006BB6), Color(0xFFF58426), Color(0xFFFFFFFF)),
        NbaTeamScheme("Brooklyn Nets", "BKN", Color(0xFF000000), Color(0xFFFFFFFF), Color(0xFFFFFFFF)),
        NbaTeamScheme("Milwaukee Bucks", "MIL", Color(0xFF00471B), Color(0xFFEEE1C6), Color(0xFFFFFFFF)),
        NbaTeamScheme("Philadelphia 76ers", "PHI", Color(0xFF006BB6), Color(0xFFED174C), Color(0xFFFFFFFF)),
        NbaTeamScheme("Dallas Mavericks", "DAL", Color(0xFF00538C), Color(0xFFB8C4CA), Color(0xFFFFFFFF)),
        NbaTeamScheme("Denver Nuggets", "DEN", Color(0xFF0E2240), Color(0xFFFEC524), Color(0xFFFFFFFF)),
        NbaTeamScheme("Phoenix Suns", "PHX", Color(0xFF1D1160), Color(0xFFE56020), Color(0xFFFFFFFF)),
        NbaTeamScheme("LA Clippers", "LAC", Color(0xFFC8102E), Color(0xFF1D428A), Color(0xFFFFFFFF)),
        NbaTeamScheme("San Antonio Spurs", "SAS", Color(0xFF000000), Color(0xFFC4CED4), Color(0xFFFFFFFF)),
        NbaTeamScheme("Houston Rockets", "HOU", Color(0xFFCE1141), Color(0xFF000000), Color(0xFFFFFFFF)),
        NbaTeamScheme("Memphis Grizzlies", "MEM", Color(0xFF5D76A9), Color(0xFF12173F), Color(0xFFFFD100)),
        NbaTeamScheme("New Orleans Pelicans", "NOP", Color(0xFF0C2340), Color(0xFFC8102E), Color(0xFFB4975A)),
        NbaTeamScheme("Oklahoma City Thunder", "OKC", Color(0xFF007AC1), Color(0xFFEF3B24), Color(0xFFFFFFFF)),
        NbaTeamScheme("Minnesota Timberwolves", "MIN", Color(0xFF0C2340), Color(0xFF78BE20), Color(0xFFFFFFFF)),
        NbaTeamScheme("Portland Trail Blazers", "POR", Color(0xFFE03A3E), Color(0xFF000000), Color(0xFFFFFFFF)),
        NbaTeamScheme("Utah Jazz", "UTA", Color(0xFF002B5C), Color(0xFFF9A01B), Color(0xFFFFFFFF)),
        NbaTeamScheme("Sacramento Kings", "SAC", Color(0xFF5A2D81), Color(0xFF63727A), Color(0xFFFFFFFF)),
        NbaTeamScheme("Atlanta Hawks", "ATL", Color(0xFFC8102E), Color(0xFFFDB927), Color(0xFFFFFFFF)),
        NbaTeamScheme("Charlotte Hornets", "CHA", Color(0xFF1D1160), Color(0xFF00788C), Color(0xFFFFFFFF)),
        NbaTeamScheme("Cleveland Cavaliers", "CLE", Color(0xFF860038), Color(0xFFFDBB30), Color(0xFFFFFFFF)),
        NbaTeamScheme("Detroit Pistons", "DET", Color(0xFFC8102E), Color(0xFF1D428A), Color(0xFFFFFFFF)),
        NbaTeamScheme("Indiana Pacers", "IND", Color(0xFF002D62), Color(0xFFFDBB30), Color(0xFFFFFFFF)),
        NbaTeamScheme("Orlando Magic", "ORL", Color(0xFF0077C0), Color(0xFFC4CED4), Color(0xFF000000)),
        NbaTeamScheme("Toronto Raptors", "TOR", Color(0xFFCE1141), Color(0xFF000000), Color(0xFFFFFFFF)),
        NbaTeamScheme("Washington Wizards", "WAS", Color(0xFF002B5C), Color(0xFFE31837), Color(0xFFFFFFFF))
    )

    fun getScheme(teamName: String): NbaTeamScheme {
        return TEAMS.firstOrNull {
            it.name.equals(teamName, ignoreCase = true) ||
                    it.abbreviation.equals(teamName, ignoreCase = true)
        } ?: TEAMS.first()
    }
}
