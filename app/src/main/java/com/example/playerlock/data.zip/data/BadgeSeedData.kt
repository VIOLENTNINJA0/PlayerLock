package com.example.playerlock.data

object BadgeSeedData {

    val BADGES: List<PlayerBadge> = listOf(
        // ── Finishing (IDs 1–11) ──────────────────────────────────────────
        PlayerBadge(id = 1,  badgeName = "Aerial Wizard",      tier = "None", category = "Finishing"),
        PlayerBadge(id = 2,  badgeName = "Float Game",         tier = "None", category = "Finishing"),
        PlayerBadge(id = 3,  badgeName = "Hook Specialist",    tier = "None", category = "Finishing"),
        PlayerBadge(id = 4,  badgeName = "Layup Mixmaster",    tier = "None", category = "Finishing"),
        PlayerBadge(id = 5,  badgeName = "Paint Prodigy",      tier = "None", category = "Finishing"),
        PlayerBadge(id = 6,  badgeName = "Physical Finisher",  tier = "None", category = "Finishing"),
        PlayerBadge(id = 7,  badgeName = "Post Fade Phenom",   tier = "None", category = "Finishing"),
        PlayerBadge(id = 8,  badgeName = "Post Powerhouse",    tier = "None", category = "Finishing"),
        PlayerBadge(id = 9,  badgeName = "Post-Up Poet",       tier = "None", category = "Finishing"),
        PlayerBadge(id = 10, badgeName = "Posterizer",         tier = "None", category = "Finishing"),
        PlayerBadge(id = 11, badgeName = "Rise Up",            tier = "None", category = "Finishing"),

        // ── Shooting (IDs 12–16) ─────────────────────────────────────────
        PlayerBadge(id = 12, badgeName = "Deadeye",             tier = "None", category = "Shooting"),
        PlayerBadge(id = 13, badgeName = "Limitless Range",     tier = "None", category = "Shooting"),
        PlayerBadge(id = 14, badgeName = "Mini Marksman",       tier = "None", category = "Shooting"),
        PlayerBadge(id = 15, badgeName = "Set Shot Specialist", tier = "None", category = "Shooting"),
        PlayerBadge(id = 16, badgeName = "Shifty Shooter",      tier = "None", category = "Shooting"),

        // ── Playmaking (IDs 17–25) ───────────────────────────────────────
        PlayerBadge(id = 17, badgeName = "Ankle Assassin",      tier = "None", category = "Playmaking"),
        PlayerBadge(id = 18, badgeName = "Bail Out",            tier = "None", category = "Playmaking"),
        PlayerBadge(id = 19, badgeName = "Break Starter",       tier = "None", category = "Playmaking"),
        PlayerBadge(id = 20, badgeName = "Dimer",               tier = "None", category = "Playmaking"),
        PlayerBadge(id = 21, badgeName = "Handles for Days",    tier = "None", category = "Playmaking"),
        PlayerBadge(id = 22, badgeName = "Lightning Launch",    tier = "None", category = "Playmaking"),
        PlayerBadge(id = 23, badgeName = "Strong Handle",       tier = "None", category = "Playmaking"),
        PlayerBadge(id = 24, badgeName = "Unpluckable",         tier = "None", category = "Playmaking"),
        PlayerBadge(id = 25, badgeName = "Versatile Visionary", tier = "None", category = "Playmaking"),

        // ── Defense (IDs 26–35) ──────────────────────────────────────────
        PlayerBadge(id = 26, badgeName = "Challenger",          tier = "None", category = "Defense"),
        PlayerBadge(id = 27, badgeName = "Glove",               tier = "None", category = "Defense"),
        PlayerBadge(id = 28, badgeName = "High-Flying Denier",  tier = "None", category = "Defense"),
        PlayerBadge(id = 29, badgeName = "Immovable Enforcer",  tier = "None", category = "Defense"),
        PlayerBadge(id = 30, badgeName = "Interceptor",         tier = "None", category = "Defense"),
        PlayerBadge(id = 31, badgeName = "Off-Ball Pest",       tier = "None", category = "Defense"),
        PlayerBadge(id = 32, badgeName = "On-Ball Menace",      tier = "None", category = "Defense"),
        PlayerBadge(id = 33, badgeName = "Paint Patroller",     tier = "None", category = "Defense"),
        PlayerBadge(id = 34, badgeName = "Pick Dodger",         tier = "None", category = "Defense"),
        PlayerBadge(id = 35, badgeName = "Post Lockdown",       tier = "None", category = "Defense"),

        // ── Rebounding (IDs 36–38) ───────────────────────────────────────
        PlayerBadge(id = 36, badgeName = "Boxout Beast",        tier = "None", category = "Rebounding"),
        PlayerBadge(id = 37, badgeName = "Pogo Stick",          tier = "None", category = "Rebounding"),
        PlayerBadge(id = 38, badgeName = "Rebound Chaser",      tier = "None", category = "Rebounding"),
    )
}
